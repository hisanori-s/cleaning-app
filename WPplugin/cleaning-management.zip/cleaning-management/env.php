<?php
// シークレットキーだけ極秘管理
return [
    'api_secret' => 'your-api-secret-here',
];