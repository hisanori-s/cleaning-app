<?php
// シークレットキーと環境設定
return [
    'api_secret' => 'Gx4dR8pLpM2aS5v9bN7cF6tY3eH1gJ4k',
];