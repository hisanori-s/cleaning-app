<?php
// シークレットキーと環境設定
return [
    'api_secret' => 'test123',
];